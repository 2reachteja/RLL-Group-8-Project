package com.shivshai.service;

import java.util.List;

import com.shivshai.entity.BookingDetails;
import com.shivshai.entity.BusDetails;
import com.shivshai.entity.Passenger;
import com.shivshai.entity.User;
import com.shivshai.utils.UserAuth;

public interface UserService {
	public User addUser(User user);

	public void updateUser(User user);

	public User getUser(Integer userId);

	public void deleteUser(Integer userId);

	public User userLogin(UserAuth auth);

	public BookingDetails addBooking(BookingDetails booking, Integer userId, Integer busNumber);

	public void deleteBooking(Integer bookingId, Integer userId);

	public List<BookingDetails> getBookingByUserId(Integer userId);

	public BusDetails findByRouteAndDate(String arrivalBusstop, String departureBusstop, String date);
	
	public BusDetails getBusByBusNumber(Integer busNumber);
	
	public Passenger updatePassenger(Passenger passenger);

}
