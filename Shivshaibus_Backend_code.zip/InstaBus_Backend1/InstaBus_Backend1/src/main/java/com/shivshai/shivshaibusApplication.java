package com.shivshai;




import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.shivshai.entity.Admin;
import com.shivshai.serviceImpl.AdminServiceImpl;



@SpringBootApplication
public class shivshaibusApplication {
	
	@Autowired
	AdminServiceImpl adminService;
	
	@PostConstruct
	public void initAdmin() {
		Admin admin = new Admin();
		admin.setAdminName("vinayak");
		admin.setPassword("Vinayak@123");
		adminService.addAdmin(admin);
	}
	
	public static void main(String[] args) {
		SpringApplication.run(shivshaibusApplication.class, args);
	}

}
