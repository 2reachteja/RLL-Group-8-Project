package com.shivshai.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shivshai.entity.Passenger;

public interface PassengerDao extends JpaRepository<Passenger, Integer> {

}
